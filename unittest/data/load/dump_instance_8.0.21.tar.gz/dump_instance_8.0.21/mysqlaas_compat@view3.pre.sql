-- MySQLShell dump 1.0.0  Distrib Ver 8.0.21 for Linux on x86_64 - for MySQL 8.0.21 (MySQL Community Server (GPL)), for Linux (x86_64)
--
-- Host: localhost    Database: mysqlaas_compat    Table: view3
-- ------------------------------------------------------
-- Server version	5.7.33

--
-- Temporary view structure for view `view3`
--

DROP TABLE IF EXISTS view3;
/*!50001 DROP VIEW IF EXISTS view3*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view3` AS SELECT 
 1 AS `1` */;
SET character_set_client = @saved_cs_client;
