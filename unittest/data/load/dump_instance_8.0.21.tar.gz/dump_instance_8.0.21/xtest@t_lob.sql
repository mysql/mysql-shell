-- MySQLShell dump 1.0.0  Distrib Ver 8.0.21 for Linux on x86_64 - for MySQL 8.0.21 (MySQL Community Server (GPL)), for Linux (x86_64)
--
-- Host: localhost    Database: xtest    Table: t_lob
-- ------------------------------------------------------
-- Server version	5.7.33

--
-- Table structure for table `t_lob`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `t_lob` (
  `c1` tinyblob,
  `c2` blob,
  `c3` mediumblob,
  `c4` longblob,
  `c5` tinytext,
  `c6` text,
  `c7` mediumtext,
  `c8` longtext,
  `c9` tinytext CHARACTER SET latin1 COLLATE latin1_bin,
  `c10` text CHARACTER SET latin1 COLLATE latin1_bin,
  `c11` mediumtext CHARACTER SET latin1 COLLATE latin1_bin,
  `c12` longtext CHARACTER SET latin1 COLLATE latin1_bin
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
