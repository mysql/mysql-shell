-- MySQLShell dump 1.0.0  Distrib Ver 8.0.21 for Linux on x86_64 - for MySQL 8.0.21 (MySQL Community Server (GPL)), for Linux (x86_64)
--
-- Host: localhost    Database: xtest
-- ------------------------------------------------------
-- Server version	5.7.33

--
-- Current Database: xtest
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `xtest` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE xtest;

--
-- Dumping events for database 'xtest'
--

--
-- Dumping routines for database 'xtest'
--

