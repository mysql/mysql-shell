-- MySQLShell dump 1.0.0  Distrib Ver 8.0.21 for Linux on x86_64 - for MySQL 8.0.21 (MySQL Community Server (GPL)), for Linux (x86_64)
--
-- Host: localhost    Database: all_features    Table: mixed_charset
-- ------------------------------------------------------
-- Server version	5.7.33

--
-- Table structure for table `mixed_charset`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `mixed_charset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `latin` varchar(200) DEFAULT NULL,
  `japanese` varchar(200) CHARACTER SET sjis DEFAULT NULL,
  `anything` varchar(200) CHARACTER SET utf8mb4 DEFAULT NULL,
  `picture` blob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
