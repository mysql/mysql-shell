-- MySQLShell dump 1.0.0  Distrib Ver 8.0.21 for Linux on x86_64 - for MySQL 8.0.21 (MySQL Community Server (GPL)), for Linux (x86_64)
--
-- Host: localhost    Database: crazy_names_db    Table: new
-- linev
-- ------------------------------------------------------
-- Server version	5.7.33

--
-- Temporary view structure for view `new
-- linev`
--

DROP TABLE IF EXISTS `new
linev`;
/*!50001 DROP VIEW IF EXISTS `new
linev`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `new
linev` AS SELECT 
 1 AS `1` */;
SET character_set_client = @saved_cs_client;
