-- MySQLShell dump 1.0.0  Distrib Ver 8.0.21 for Linux on x86_64 - for MySQL 8.0.21 (MySQL Community Server (GPL)), for Linux (x86_64)
--
-- Host: localhost    Database: xtest    Table: t_geom_all
-- ------------------------------------------------------
-- Server version	5.7.33

--
-- Table structure for table `t_geom_all`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `t_geom_all` (
  `g` geometry DEFAULT NULL,
  `p` point DEFAULT NULL,
  `l` linestring DEFAULT NULL,
  `pl` polygon DEFAULT NULL,
  `mp` multipoint DEFAULT NULL,
  `ml` multilinestring DEFAULT NULL,
  `mpl` multipolygon DEFAULT NULL,
  `gc` geometrycollection DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
