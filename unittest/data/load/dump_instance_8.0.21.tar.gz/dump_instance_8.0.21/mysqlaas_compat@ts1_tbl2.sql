-- MySQLShell dump 1.0.0  Distrib Ver 8.0.21 for Linux on x86_64 - for MySQL 8.0.21 (MySQL Community Server (GPL)), for Linux (x86_64)
--
-- Host: localhost    Database: mysqlaas_compat    Table: ts1_tbl2
-- ------------------------------------------------------
-- Server version	5.7.33

--
-- Table structure for table `ts1_tbl2`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `ts1_tbl2` (
  `pk` int(11) NOT NULL,
  `val` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`pk`)
) /*!50100 TABLESPACE `innodb_system` */ ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;
