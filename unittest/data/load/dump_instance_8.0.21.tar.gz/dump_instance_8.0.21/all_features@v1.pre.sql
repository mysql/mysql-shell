-- MySQLShell dump 1.0.0  Distrib Ver 8.0.21 for Linux on x86_64 - for MySQL 8.0.21 (MySQL Community Server (GPL)), for Linux (x86_64)
--
-- Host: localhost    Database: all_features    Table: v1
-- ------------------------------------------------------
-- Server version	5.7.33

--
-- Temporary view structure for view `v1`
--

DROP TABLE IF EXISTS v1;
/*!50001 DROP VIEW IF EXISTS v1*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v1` AS SELECT 
 1 AS a */;
SET character_set_client = @saved_cs_client;
