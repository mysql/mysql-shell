-- MySQLShell dump 1.0.0  Distrib Ver 8.0.21 for Linux on x86_64 - for MySQL 8.0.21 (MySQL Community Server (GPL)), for Linux (x86_64)
--
-- Host: localhost
-- ------------------------------------------------------
-- Server version	5.7.33
--
-- Dumping user accounts
--

-- begin user root@%
CREATE USER IF NOT EXISTS 'root'@'%' IDENTIFIED WITH 'mysql_native_password' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
/* ALTER USER 'root'@'%' IDENTIFIED WITH 'mysql_native_password' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK; */
-- end user root@%

-- begin user root@localhost
CREATE USER IF NOT EXISTS 'root'@'localhost' IDENTIFIED WITH 'mysql_native_password' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
/* ALTER USER 'root'@'localhost' IDENTIFIED WITH 'mysql_native_password' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK; */
-- end user root@localhost

-- begin user test@%
CREATE USER IF NOT EXISTS 'test'@'%' IDENTIFIED WITH 'mysql_native_password' AS '*94BDCEBE19083CE2A1F959FD02F964C7AF4CFC29' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
/* ALTER USER 'test'@'%' IDENTIFIED WITH 'mysql_native_password' AS '*94BDCEBE19083CE2A1F959FD02F964C7AF4CFC29' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK; */
-- end user test@%

-- begin user testusr1@localhost
CREATE USER IF NOT EXISTS 'testusr1'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
/* ALTER USER 'testusr1'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK; */
-- end user testusr1@localhost

-- begin user testusr2@localhost
CREATE USER IF NOT EXISTS 'testusr2'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
/* ALTER USER 'testusr2'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK; */
-- end user testusr2@localhost

-- begin user testusr3@localhost
CREATE USER IF NOT EXISTS 'testusr3'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
/* ALTER USER 'testusr3'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK; */
-- end user testusr3@localhost

-- begin user testusr4@localhost
CREATE USER IF NOT EXISTS 'testusr4'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
/* ALTER USER 'testusr4'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK; */
-- end user testusr4@localhost

-- begin user testusr5@localhost
CREATE USER IF NOT EXISTS 'testusr5'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
/* ALTER USER 'testusr5'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK; */
-- end user testusr5@localhost

-- begin user testusr6@localhost
CREATE USER IF NOT EXISTS 'testusr6'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK;
/* ALTER USER 'testusr6'@'localhost' IDENTIFIED WITH 'mysql_native_password' AS '*196BDEDE2AE4F84CA44C47D54D78478C7E2BD7B7' REQUIRE NONE PASSWORD EXPIRE DEFAULT ACCOUNT UNLOCK; */
-- end user testusr6@localhost

-- begin grants root@%
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' WITH GRANT OPTION;
-- end grants root@%

-- begin grants root@localhost
GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION;
GRANT PROXY ON ''@'' TO 'root'@'localhost' WITH GRANT OPTION;
-- end grants root@localhost

-- begin grants test@%
GRANT USAGE ON *.* TO 'test'@'%';
GRANT SELECT ON `test`.* TO 'test'@'%';
-- end grants test@%

-- begin grants testusr1@localhost
GRANT RELOAD, FILE, SUPER ON *.* TO 'testusr1'@'localhost';
-- end grants testusr1@localhost

-- begin grants testusr2@localhost
GRANT SUPER ON *.* TO 'testusr2'@'localhost';
-- end grants testusr2@localhost

-- begin grants testusr3@localhost
GRANT RELOAD, FILE ON *.* TO 'testusr3'@'localhost' WITH GRANT OPTION;
-- end grants testusr3@localhost

-- begin grants testusr4@localhost
GRANT SUPER, REPLICATION SLAVE ON *.* TO 'testusr4'@'localhost';
-- end grants testusr4@localhost

-- begin grants testusr5@localhost
GRANT SELECT, INSERT, UPDATE, DELETE, FILE, REPLICATION SLAVE ON *.* TO 'testusr5'@'localhost';
-- end grants testusr5@localhost

-- begin grants testusr6@localhost
GRANT FILE ON *.* TO 'testusr6'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE ON `mysql`.* TO 'testusr6'@'localhost' WITH GRANT OPTION;
GRANT SELECT, INSERT, UPDATE, DELETE ON `mysqlaas_compat`.* TO 'testusr6'@'localhost';
-- end grants testusr6@localhost

FLUSH PRIVILEGES;
-- End of dumping user accounts

