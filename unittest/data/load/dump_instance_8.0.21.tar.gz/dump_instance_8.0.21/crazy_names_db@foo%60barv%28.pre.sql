-- MySQLShell dump 1.0.0  Distrib Ver 8.0.21 for Linux on x86_64 - for MySQL 8.0.21 (MySQL Community Server (GPL)), for Linux (x86_64)
--
-- Host: localhost    Database: crazy_names_db    Table: foo`barv(
-- ------------------------------------------------------
-- Server version	5.7.33

--
-- Temporary view structure for view `foo``barv(`
--

DROP TABLE IF EXISTS `foo``barv(`;
/*!50001 DROP VIEW IF EXISTS `foo``barv(`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `foo``barv(` AS SELECT 
 1 AS `1` */;
SET character_set_client = @saved_cs_client;
